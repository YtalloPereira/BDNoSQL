package BD2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DistribuidorServico {
	
	@Autowired
	private DistribuidorRepositorio distribuidorRepositorio;
	
	public void save(Distribuidor novo) {
		this.distribuidorRepositorio.save(novo);
	}
	
	public void SaveAll(List<Distribuidor> distribuidores) {
		this.distribuidorRepositorio.saveAll(distribuidores);
	}
	
	public List<Distribuidor> getAll() {
		return this.distribuidorRepositorio.findAll();
	}
	
	public Distribuidor getById(String id) {
		return this.distribuidorRepositorio.findById(id).get();
	}
	
	public void deleteAll() {
		this.distribuidorRepositorio.deleteAll();
	}
	
	public void deleteById(String id) {
		this.distribuidorRepositorio.deleteById(id);
	}
	
	public void update(Distribuidor distribuidor) {
		this.distribuidorRepositorio.save(distribuidor);
	}

}
