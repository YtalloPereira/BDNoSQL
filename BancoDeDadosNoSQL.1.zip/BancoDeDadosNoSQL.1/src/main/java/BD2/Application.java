package BD2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	@Autowired
	private ProdutoServico produtoServico;
	@Autowired
	private DistribuidorServico distribuidorServico;
	
	public void run(String... args) throws Exception {
		Scanner leitor = new Scanner(System.in);
		while(true) {
			System.out.println("\n1 - Salvar todos \n2 - Listar todos \n3 - Listar por ID\n4 - Deletar por ID \n"
					+ "5 - Deletar todos \n6 - Atualizar registro usando o ID ");
			int entrada = Integer.parseInt(leitor.nextLine());	
			
			if(entrada == 1) {
				
				Distribuidor d1 = new Distribuidor("Malwee","22.222.222/0001-22");
				Distribuidor d2 = new Distribuidor("Lacoste","33.333.333/0001-33");	
				this.distribuidorServico.save(d2);
				this.distribuidorServico.save(d1);
				
				Produto p1 = new Produto("Camisa", "Camisa Branca", 60, d1);
				Produto p2 = new Produto("Camisa", "Camisa Branca", 60, d1);
				Produto p3 = new Produto("Blusa", "Blusa Azul", 70, d1);
				Produto p4 = new Produto("Blusa", "Blusa Azul", 70, d2);
				Produto p5 = new Produto("Casaco", "Casaco Vermelho com Listras Pretas", 80, d2);
				Produto p6 = new Produto("Casaco", "Casaco Vermelho com Listras Pretas", 80, d2);
				
				List<Produto> produtos = new ArrayList<Produto>();
				produtos.add(p1);
				produtos.add(p2);
				produtos.add(p3);
				produtos.add(p4);
				produtos.add(p5);
				produtos.add(p6);
				this.produtoServico.SaveAll(produtos);
			
			}else if(entrada == 2) {
				List<Produto> produtosGetall = new ArrayList<Produto>();
				produtosGetall = this.produtoServico.getAll();
				for (Produto produto : produtosGetall) {
					System.out.println(produto.toString());
					System.out.println("-----------------------------------------------------------------------------------------");
				}
			}else if(entrada == 3) {
				System.out.println("Insira o ID: ");
				String id = leitor.nextLine();
				Produto resultado = this.produtoServico.getById(id);
				System.out.println(resultado.toString());
								
			}else if(entrada == 4) {
				System.out.println("Insira o ID: ");
				String id = leitor.nextLine();
				System.out.println("Registro Removido: ");
				Produto resultado = this.produtoServico.getById(id);
				System.out.println(resultado.toString());
				this.produtoServico.deleteById(id);
			
			}else if(entrada == 5) {
				this.produtoServico.deleteAll();
				System.out.println("Todos os registros foram deletados");
			
			}else if(entrada == 6) {
				System.out.println("Insira o ID: ");
				String id = leitor.nextLine();
				Produto resultado = this.produtoServico.getById(id);
				resultado.setNome("Meia");
				resultado.setDescricao("Meia do Clube de Regatas Flamengo (Casa)");
				this.produtoServico.save(resultado);
			}
			else if(entrada == 0){
				break;
			}
		}		
		
		leitor.close();
	}
}
