package BD2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	@Autowired
	private ProdutoServico produtoServico;
	
	public void run(String... args) throws Exception {
		
//		this.produtoServico.save("Blusa", "Blusa Azul", 70);
//		this.produtoServico.save("Blusa", "Blusa Vermelha com Listras Pretas", 80);
//		this.produtoServico.save("Blusa", "Blusa Vermelha com Listras Pretas", 80);
		
		List<Produto> produtos = new ArrayList<Produto>();
		produtos = this.produtoServico.findAll();
		for (Produto produto : produtos) {
			System.out.println(produto.toString());
		}
	}
}
