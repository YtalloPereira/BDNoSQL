package BD2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProdutoServico {
	
	@Autowired
	private ProdutoRepositorio produtoRepositorio;
	
	public void save(Produto novo) {
		this.produtoRepositorio.save(novo);
	}
	
	public void SaveAll(List<Produto> produtos) {
		this.produtoRepositorio.saveAll(produtos);
	}
	
	public List<Produto> getAll() {
		return this.produtoRepositorio.findAll();
	}
	
	public Produto getById(String id) {
		return this.produtoRepositorio.findById(id).get();
	}
	
	public void deleteAll() {
		this.produtoRepositorio.deleteAll();
	}
	
	public void deleteById(String id) {
		this.produtoRepositorio.deleteById(id);
	}
	
	public void update(Produto produto) {
		this.produtoRepositorio.save(produto);
	}
}
