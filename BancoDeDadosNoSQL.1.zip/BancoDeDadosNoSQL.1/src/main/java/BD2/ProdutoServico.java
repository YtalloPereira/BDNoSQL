package BD2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProdutoServico {
	
	@Autowired
	private ProdutoRepositorio produtoRepositorio;
	
	public void save(String nome, String descricao, long preco) {
		Produto novo = new Produto(nome, descricao, preco);
		this.produtoRepositorio.save(novo);
	}
	
	public List<Produto> findAll() {
		return this.produtoRepositorio.findAll();
	}
	
	
}
